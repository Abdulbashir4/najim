<?php
/**
 * Codgen Portable Base Config
 * Works under: /tarek/codgen, /basir/codgen, /najim/codgen etc
 */

define('CODGEN_ROOT', realpath(__DIR__)); // .../codgen
define('CODGEN_BASE_URL', rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\')); 
// example: /tarek/codgen/function  -> remove /function when needed below

// ---- detect codgen base like /tarek/codgen ----
$uri = $_SERVER['SCRIPT_NAME']; 
// /tarek/codgen/function/dashboard.php

$pos = strpos($uri, '/codgen/');
if ($pos !== false) {
    $base = substr($uri, 0, $pos) . '/codgen';
} else {
    // fallback (rare)
    $base = rtrim(dirname($uri), '/\\');
}

define('CODGEN_BASE', $base);

// Example output:
// CODGEN_BASE = /tarek/codgen
// CODGEN_BASE = /basir/codgen
