<?php
require_once __DIR__ . '/../../server_connection.php';



// ======= GET TABLE LIST =======
$tables = [];
$result = $conn->query("SHOW TABLES");
if ($result) {
    while ($row = $result->fetch_array()) {
        $tables[] = $row[0];
    }
}

// ======= TABLE ROW COUNT FUNCTION =======
function getRowCount($conn, $tableName) {
    $countRes = $conn->query("SELECT COUNT(*) AS total FROM `$tableName`");
    if ($countRes) {
        $countRow = $countRes->fetch_assoc();
        return (int)$countRow['total'];
    }
    return 0;
}

// ======= TABLE COLUMN COUNT FUNCTION =======
function getColumnCount($conn, $dbName, $tableName) {
    $dbNameEsc  = $conn->real_escape_string($dbName);
    $tableEsc   = $conn->real_escape_string($tableName);

    $sql = "SELECT COUNT(*) AS total 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = '$dbNameEsc' 
              AND TABLE_NAME = '$tableEsc'";

    $colRes = $conn->query($sql);
    if ($colRes) {
        $colRow = $colRes->fetch_assoc();
        return (int)$colRow['total'];
    }
    return 0;
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Database Tables</title>
</head>
<body class="bg-gray-50">

<div class="max-w-6xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">📌 ডাটাবেস টেবিল লিস্ট</h1>
        <div class="text-sm text-gray-600">
            Database: <span class="font-semibold text-gray-800"><?= htmlspecialchars($dbname) ?></span>
        </div>
    </div>

    <div class="bg-white shadow rounded-xl overflow-hidden border">
        <table class="w-full text-left">
            <thead class="bg-gray-100">
                <tr class="text-gray-700 text-sm uppercase tracking-wide">
                    <th class="px-5 py-3 w-16">#</th>
                    <th class="px-5 py-3">Table Name</th>
                    <th class="px-5 py-3 w-28">Columns</th>
                    <th class="px-5 py-3 w-28">Rows</th>
                    <th class="px-5 py-3 w-32">Action</th>
                </tr>
            </thead>

            <tbody class="divide-y">
                <?php if (empty($tables)): ?>
                    <tr>
                        <td colspan="5" class="px-5 py-6 text-center text-gray-500">
                            কোনো টেবিল পাওয়া যায়নি।
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($tables as $i => $tableName): ?>
                        <?php
                            $rowCount = getRowCount($conn, $tableName);
                            $colCount = getColumnCount($conn, $dbname, $tableName);
                        ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-5 py-3 text-sm text-gray-600"><?= $i + 1 ?></td>

                            <td class="px-5 py-3 font-semibold text-gray-800">
                                <?= htmlspecialchars($tableName) ?>
                            </td>

                            <td class="px-5 py-3 text-sm text-gray-700">
                                <?= $colCount ?>
                            </td>

                            <td class="px-5 py-3 text-sm text-gray-700">
                                <?= $rowCount ?>
                            </td>

                            <td class="px-5 py-3">
                                <a href="view_table.php?table=<?= urlencode($tableName) ?>"
                                   class="inline-flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg bg-blue-600 text-white text-sm hover:bg-blue-700">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-5 text-sm text-gray-600">
        Total Tables: <span class="font-bold text-gray-800"><?= count($tables) ?></span>
    </div>
</div>

</body>
</html>

<?php $conn->close(); ?>
