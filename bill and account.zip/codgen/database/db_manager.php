<?php
require_once __DIR__ . '/../../server_connection.php';

function h($v){ return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }

$msg = "";
$err = "";

// ======= Handle Actions =======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  // Create Table
  if (isset($_POST['action']) && $_POST['action'] === 'create_table') {
    $newTable = trim($_POST['new_table'] ?? '');
    $newTable = preg_replace('/[^a-zA-Z0-9_]/', '', $newTable);

    if ($newTable === "") {
      $err = "Table name required!";
    } else {
      $sql = "CREATE TABLE `$newTable` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB";

      if ($conn->query($sql)) $msg = "✅ Table created: $newTable";
      else $err = "❌ Create failed: " . $conn->error;
    }
  }

  // Drop Table
  if (isset($_POST['action']) && $_POST['action'] === 'drop_table') {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['table'] ?? '');
    if ($table) {
      if ($conn->query("DROP TABLE `$table`")) $msg = "✅ Table deleted: $table";
      else $err = "❌ Delete failed: " . $conn->error;
    }
  }

  // Add Column
  if (isset($_POST['action']) && $_POST['action'] === 'add_column') {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['table'] ?? '');
    $col   = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['col_name'] ?? '');
    $type  = strtoupper(trim($_POST['col_type'] ?? 'VARCHAR(255)'));
    $null  = isset($_POST['col_null']) ? "NULL" : "NOT NULL";
    $def   = trim($_POST['col_default'] ?? '');

    if (!$table || !$col) {
      $err = "Table/Column missing!";
    } else {
      $defaultSql = "";
      if ($def !== "") {
        // allow only safe default (string numeric)
        $defEsc = $conn->real_escape_string($def);
        $defaultSql = " DEFAULT '$defEsc'";
      }

      $sql = "ALTER TABLE `$table` ADD `$col` $type $null $defaultSql";

      if ($conn->query($sql)) $msg = "✅ Column added: $table.$col";
      else $err = "❌ Add column failed: " . $conn->error;
    }
  }

  // Drop Column
  if (isset($_POST['action']) && $_POST['action'] === 'drop_column') {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['table'] ?? '');
    $col   = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['column'] ?? '');

    if ($table && $col) {
      if ($conn->query("ALTER TABLE `$table` DROP COLUMN `$col`")) {
        $msg = "✅ Column deleted: $table.$col";
      } else {
        $err = "❌ Delete column failed: " . $conn->error;
      }
    }
  }
}

// ======= Tables =======
$tables = [];
$res = $conn->query("SHOW TABLES");
if ($res) {
  while($row = $res->fetch_array()) $tables[] = $row[0];
}

// ======= Selected Table =======
$selectedTable = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
$columns = [];

if ($selectedTable) {
  $colRes = $conn->query("SHOW COLUMNS FROM `$selectedTable`");
  if ($colRes) {
    while($c = $colRes->fetch_assoc()) $columns[] = $c;
  }
}

// Row count helper
function getRowCount($conn, $t){
  $r = $conn->query("SELECT COUNT(*) AS total FROM `$t`");
  if ($r) return (int)$r->fetch_assoc()['total'];
  return 0;
}

// Column count helper
function getColCount($conn, $db, $t){
  $dbEsc = $conn->real_escape_string($db);
  $tEsc  = $conn->real_escape_string($t);
  $q = "SELECT COUNT(*) total FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA='$dbEsc' AND TABLE_NAME='$tEsc'";
  $r = $conn->query($q);
  if ($r) return (int)$r->fetch_assoc()['total'];
  return 0;
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <title>DB Manager</title>
</head>
<body class="bg-slate-50">

<div class="max-w-7xl mx-auto p-6">

  <div class="flex items-center justify-between mb-4">
    <div>
      <h1 class="text-2xl font-bold text-gray-800">🗃️ Database Manager</h1>
      <p class="text-sm text-gray-500">Create/Delete tables and manage columns</p>
    </div>

    <div class="text-sm bg-white border rounded-xl px-4 py-2">
      DB: <b><?= h($dbname) ?></b>
    </div>
  </div>

  <?php if($msg): ?>
    <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl text-green-700"><?= h($msg) ?></div>
  <?php endif; ?>
  <?php if($err): ?>
    <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700"><?= h($err) ?></div>
  <?php endif; ?>

  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

    <!-- Left: Tables -->
    <div class="bg-white border rounded-2xl p-4">
      <div class="flex items-center justify-between mb-3">
        <h2 class="font-bold text-gray-800">Tables</h2>
        <span class="text-xs text-gray-500"><?= count($tables) ?> total</span>
      </div>

      <!-- Create table -->
      <form method="POST" class="flex gap-2 mb-4">
        <input type="hidden" name="action" value="create_table">
        <input name="new_table" placeholder="new_table_name"
               class="w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring"
               required>
        <button class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold">
          Add
        </button>
      </form>

      <div class="space-y-2 max-h-[55vh] overflow-auto pr-1">
        <?php foreach($tables as $t): ?>
          <?php
            $isActive = ($selectedTable === $t);
            $rows = getRowCount($conn, $t);
            $cols = getColCount($conn, $dbname, $t);
          ?>
          <div class="border rounded-xl px-3 py-2 <?= $isActive ? "bg-blue-50 border-blue-200" : "bg-white" ?>">
            <div class="flex items-center justify-between">
              <a href="?table=<?= urlencode($t) ?>"
                 class="font-semibold text-gray-800 hover:text-blue-700">
                <?= h($t) ?>
              </a>

              <form method="POST" onsubmit="return confirm('Are you sure to delete table: <?= h($t) ?> ?')">
                <input type="hidden" name="action" value="drop_table">
                <input type="hidden" name="table" value="<?= h($t) ?>">
                <button class="text-xs px-2 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white">
                  Delete
                </button>
              </form>
            </div>

            <div class="mt-1 text-xs text-gray-500">
              Columns: <b><?= $cols ?></b> • Rows: <b><?= $rows ?></b>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Right: Columns Manager -->
    <div class="md:col-span-2 bg-white border rounded-2xl p-4">
      <?php if(!$selectedTable): ?>
        <div class="text-gray-500 text-sm">
          👈 বাম পাশ থেকে একটি table select করুন। তারপর columns manage করতে পারবেন।
        </div>
      <?php else: ?>
        <div class="flex items-center justify-between mb-3">
          <div>
            <h2 class="font-bold text-gray-800">Table: <?= h($selectedTable) ?></h2>
            <p class="text-xs text-gray-500">Manage columns (add/delete)</p>
          </div>
          <a href="db_manager_data.php?table=<?= urlencode($selectedTable) ?>"
     class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold">
    🧩 Manage Data
  </a>
        </div>

        <!-- Add Column -->
        <form method="POST" class="grid grid-cols-1 md:grid-cols-5 gap-2 mb-4">
          <input type="hidden" name="action" value="add_column">
          <input type="hidden" name="table" value="<?= h($selectedTable) ?>">

          <input name="col_name" placeholder="column_name" required
                 class="border rounded-xl px-3 py-2 text-sm">

          <select name="col_type" class="border rounded-xl px-3 py-2 text-sm">
            <option value="VARCHAR(255)">VARCHAR(255)</option>
            <option value="INT">INT</option>
            <option value="BIGINT">BIGINT</option>
            <option value="DECIMAL(10,2)">DECIMAL(10,2)</option>
            <option value="TEXT">TEXT</option>
            <option value="DATE">DATE</option>
            <option value="DATETIME">DATETIME</option>
            <option value="TIMESTAMP">TIMESTAMP</option>
          </select>

          <input name="col_default" placeholder="default (optional)"
                 class="border rounded-xl px-3 py-2 text-sm">

          <label class="flex items-center gap-2 border rounded-xl px-3 py-2 text-sm">
            <input type="checkbox" name="col_null"> NULL
          </label>

          <button class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold">
            Add Column
          </button>
        </form>

        <!-- Columns List -->
        <div class="overflow-auto border rounded-2xl">
          <table class="w-full text-sm">
            <thead class="bg-slate-100">
              <tr class="text-gray-700">
                <th class="text-left px-4 py-3">Field</th>
                <th class="text-left px-4 py-3">Type</th>
                <th class="text-left px-4 py-3">Null</th>
                <th class="text-left px-4 py-3">Default</th>
                <th class="text-left px-4 py-3 w-24">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y">
              <?php foreach($columns as $c): ?>
                <tr class="hover:bg-slate-50">
                  <td class="px-4 py-2 font-semibold"><?= h($c['Field']) ?></td>
                  <td class="px-4 py-2"><?= h($c['Type']) ?></td>
                  <td class="px-4 py-2"><?= h($c['Null']) ?></td>
                  <td class="px-4 py-2"><?= h($c['Default']) ?></td>
                  <td class="px-4 py-2">
                    <?php if($c['Field'] !== 'id'): ?>
                      <form method="POST"
                            onsubmit="return confirm('Delete column <?= h($c['Field']) ?> ?')">
                        <input type="hidden" name="action" value="drop_column">
                        <input type="hidden" name="table" value="<?= h($selectedTable) ?>">
                        <input type="hidden" name="column" value="<?= h($c['Field']) ?>">
                        <button class="px-2 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs">
                          Delete
                        </button>
                      </form>
                    <?php else: ?>
                      <span class="text-xs text-gray-400">Locked</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

</body>
</html>
<?php $conn->close(); ?>
