<?php
require_once __DIR__ . '/../../server_connection.php';

function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function cleanName($v){ return preg_replace('/[^a-zA-Z0-9_]/', '', (string)$v); }

// Tables list
$tables = [];
$res = $conn->query("SHOW TABLES");
if($res){
  while($r = $res->fetch_array()) $tables[] = $r[0];
}

// selected table
$selectedTable = cleanName($_GET['table'] ?? '');

// columns list
$columns = [];
if($selectedTable){
  $colRes = $conn->query("SHOW COLUMNS FROM `$selectedTable`");
  if($colRes){
    while($c = $colRes->fetch_assoc()){
      // Field, Type, Null, Key, Default, Extra
      $columns[] = $c;
    }
  }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Form Generator</title>
</head>
<body class="bg-slate-50">
<div class="max-w-7xl mx-auto p-6">

  <!-- Header -->
  <div class="flex items-center justify-between mb-5">
    <div>
      <h1 class="text-2xl font-bold text-gray-800">🧩 Form Generator</h1>
      <p class="text-sm text-gray-500">Select table & columns → generate form code</p>
    </div>

    <a href="db_manager.php"
       class="px-4 py-2 rounded-xl bg-white border hover:bg-slate-50 text-sm font-semibold">
      ← Back DB Manager
    </a>
  </div>

  <!-- Table Select -->
  <form method="GET" class="bg-white border rounded-2xl p-4 mb-4">
    <label class="text-sm font-semibold text-gray-700">Select Table</label>
    <div class="flex gap-2 mt-2">
      <select name="table" class="border rounded-xl px-3 py-2 text-sm w-80">
        <option value="">-- Select Table --</option>
        <?php foreach($tables as $t): ?>
          <option value="<?= h($t) ?>" <?= $selectedTable===$t?'selected':'' ?>>
            <?= h($t) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <button class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold">
        Load Columns
      </button>
    </div>
  </form>

  <?php if(!$selectedTable): ?>
    <div class="text-gray-500 text-sm">👆 আগে একটি table select করুন।</div>
  <?php else: ?>

  <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

    <!-- LEFT: Column mapping -->
    <div class="bg-white border rounded-2xl p-4">
      <div class="flex items-center justify-between mb-3">
        <h2 class="font-bold text-gray-800">✅ Column Select & Field Type</h2>
        <span class="text-xs text-gray-500">Table: <b><?= h($selectedTable) ?></b></span>
      </div>

      <div class="text-xs text-gray-500 mb-3">
        ✅ যে column গুলোতে form data যাবে শুধু সেগুলো check করুন।  
        (auto_increment/id সাধারণত বাদ দিন)
      </div>

      <div class="space-y-3 max-h-[65vh] overflow-auto pr-2">
        <?php foreach($columns as $c): 
          $f = $c['Field'];
          $type = strtolower($c['Type']);
          $isAuto = (stripos($c['Extra'], 'auto_increment') !== false);
        ?>
          <div class="border rounded-2xl p-3">
            <div class="flex items-center justify-between gap-2">
              <label class="flex items-center gap-2">
                <input type="checkbox" class="colCheck"
                       data-field="<?= h($f) ?>"
                       <?= $isAuto ? '' : 'checked' ?>>
                <span class="font-semibold text-gray-800"><?= h($f) ?></span>
              </label>

              <span class="text-xs text-gray-500"><?= h($c['Type']) ?></span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-2 mt-3">
              <div>
                <label class="text-xs text-gray-600 font-semibold">Input Type</label>
                <select class="inputType border rounded-xl px-3 py-2 text-sm w-full"
                        data-field="<?= h($f) ?>">
                  <option value="text">text</option>
                  <option value="number" <?= str_contains($type,'int') || str_contains($type,'decimal') ? 'selected':'' ?>>number</option>
                  <option value="date" <?= str_contains($type,'date') ? 'selected':'' ?>>date</option>
                  <option value="datetime-local" <?= str_contains($type,'datetime') ? 'selected':'' ?>>datetime-local</option>
                  <option value="textarea" <?= str_contains($type,'text') ? 'selected':'' ?>>textarea</option>
                  <option value="select">select</option>
                  <option value="file">file</option>
                </select>
              </div>

              <div>
                <label class="text-xs text-gray-600 font-semibold">Label</label>
                <input class="labelText border rounded-xl px-3 py-2 text-sm w-full"
                       data-field="<?= h($f) ?>"
                       value="<?= h(ucwords(str_replace('_',' ', $f))) ?>">
              </div>

              <div>
                <label class="text-xs text-gray-600 font-semibold">Required</label>
                <div class="flex items-center gap-2 border rounded-xl px-3 py-2">
                  <input type="checkbox" class="requiredCheck"
                         data-field="<?= h($f) ?>"
                         <?= ($c['Null'] === 'NO' && !$isAuto) ? 'checked':'' ?>>
                  <span class="text-sm text-gray-700">required</span>
                </div>
              </div>
            </div>

            <!-- Select options -->
            <div class="mt-3 selectBox hidden" data-field="<?= h($f) ?>">
              <label class="text-xs text-gray-600 font-semibold">Select Options (comma separated)</label>
              <input class="selectOptions border rounded-xl px-3 py-2 text-sm w-full"
                     data-field="<?= h($f) ?>"
                     placeholder="example: pending,paid,cancelled">
            </div>

          </div>
        <?php endforeach; ?>
      </div>

      <button onclick="generateAll()" type="button"
              class="mt-4 w-full px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold">
        ⚡ Generate Code
      </button>
    </div>

    <!-- RIGHT: Generated Code -->
    <div class="bg-white border rounded-2xl p-4">
      <div class="flex items-center justify-between mb-3">
        <h2 class="font-bold text-gray-800">🧾 Generated Code</h2>
        <div class="flex gap-2">
          <button onclick="copyCode('formCode')" type="button"
                  class="px-3 py-1.5 rounded-lg bg-gray-800 hover:bg-black text-white text-xs font-semibold">
            Copy Form
          </button>
          <button onclick="copyCode('saveCode')" type="button"
                  class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold">
            Copy Save File
          </button>
        </div>
      </div>

      <p class="text-xs text-gray-500 mb-3">
        ✅ 1) Form file: <b>form_<?= h($selectedTable) ?>.php</b><br>
        ✅ 2) Save file: <b>save_<?= h($selectedTable) ?>.php</b>
      </p>

      <label class="text-xs font-bold text-gray-600">Form Code</label>
      <textarea id="formCode" class="w-full mt-2 h-[35vh] border rounded-2xl p-3 font-mono text-xs"></textarea>

      <label class="text-xs font-bold text-gray-600 mt-4 block">Save File Code</label>
      <textarea id="saveCode" class="w-full mt-2 h-[35vh] border rounded-2xl p-3 font-mono text-xs"></textarea>
    </div>

  </div>

  <?php endif; ?>

</div>

<script>
const tableName = <?= json_encode($selectedTable) ?>;

function qs(sel){ return document.querySelector(sel); }
function qsa(sel){ return [...document.querySelectorAll(sel)]; }

function copyCode(id){
  const ta = document.getElementById(id);
  ta.select();
  document.execCommand("copy");
  alert("✅ Copied!");
}

function generateAll(){
  // Read field configs
  const selectedFields = [];

  qsa(".colCheck").forEach(chk => {
    const field = chk.dataset.field;
    const enabled = chk.checked;

    const type = qs(`.inputType[data-field="${field}"]`).value;
    const label = qs(`.labelText[data-field="${field}"]`).value;
    const required = qs(`.requiredCheck[data-field="${field}"]`).checked;
    const optsEl = qs(`.selectOptions[data-field="${field}"]`);
    const options = optsEl ? optsEl.value.trim() : "";

    if(enabled){
      selectedFields.push({ field, type, label, required, options });
    }
  });

  if(selectedFields.length === 0){
    alert("❌ At least one column select করুন!");
    return;
  }

  // Build Form Code
  let form = `<?php /* Auto Generated Form */ ?>\n`;
  form += `<!DOCTYPE html>\n<html lang="bn">\n<head>\n`;
  form += `  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n`;
  form += `  <script src="https://cdn.tailwindcss.com"><\\/script>\n`;
  form += `  <title>${tableName} Form</title>\n</head>\n<body class="bg-slate-50">\n`;
  form += `<div class="max-w-3xl mx-auto p-6">\n`;
  form += `<div class="bg-white border rounded-2xl p-6">\n`;
  form += `<h1 class="text-2xl font-bold text-gray-800 mb-1">${tableName} Form</h1>\n`;
  form += `<p class="text-sm text-gray-500 mb-6">Auto generated form</p>\n`;
  form += `<form action="save_${tableName}.php" method="POST" class="space-y-4" enctype="multipart/form-data">\n\n`;

  selectedFields.forEach(f => {
    const req = f.required ? "required" : "";
    form += `  <div>\n`;
    form += `    <label class="text-sm font-semibold text-gray-700">${escapeHtml(f.label)}</label>\n`;

    if(f.type === "textarea"){
      form += `    <textarea name="${f.field}" ${req} class="mt-1 w-full border rounded-xl px-3 py-2" rows="4"></textarea>\n`;
    } else if(f.type === "select"){
      const opts = f.options ? f.options.split(",").map(x => x.trim()).filter(Boolean) : [];
      form += `    <select name="${f.field}" ${req} class="mt-1 w-full border rounded-xl px-3 py-2">\n`;
      form += `      <option value="">-- Select --</option>\n`;
      opts.forEach(o => {
        form += `      <option value="${escapeHtml(o)}">${escapeHtml(o)}</option>\n`;
      });
      form += `    </select>\n`;
    } else {
      form += `    <input type="${f.type}" name="${f.field}" ${req} class="mt-1 w-full border rounded-xl px-3 py-2">\n`;
    }

    form += `  </div>\n\n`;
  });

  form += `  <button class="w-full px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold">\n`;
  form += `    Save\n  </button>\n`;
  form += `</form>\n</div>\n</div>\n</body>\n</html>\n`;

  // Build Save Code (prepared statement)
  let save = `<?php\nrequire_once __DIR__ . "/../../server_connection.php";\n\n`;
  save += `// Auto Generated Save File\n`;
  save += `$msg = "";\n$err = "";\n\n`;
  save += `if($_SERVER["REQUEST_METHOD"] === "POST"){\n`;

  // handle file inputs (basic)
  selectedFields.forEach(f => {
    if(f.type === "file"){
      save += `  // File upload: ${f.field}\n`;
      save += `  $${f.field} = "";\n`;
      save += `  if(isset($_FILES["${f.field}"]) && $_FILES["${f.field}"]["error"] === UPLOAD_ERR_OK){\n`;
      save += `    $ext = pathinfo($_FILES["${f.field}"]["name"], PATHINFO_EXTENSION);\n`;
      save += `    $newName = "${f.field}_" . time() . "." . $ext;\n`;
      save += `    $path = __DIR__ . "/uploads/" . $newName;\n`;
      save += `    if(!is_dir(__DIR__ . "/uploads")) mkdir(__DIR__ . "/uploads", 0777, true);\n`;
      save += `    move_uploaded_file($_FILES["${f.field}"]["tmp_name"], $path);\n`;
      save += `    $${f.field} = "uploads/" . $newName;\n`;
      save += `  }\n\n`;
    }
  });

  selectedFields.forEach(f => {
    if(f.type !== "file"){
      save += `  $${f.field} = $_POST["${f.field}"] ?? "";\n`;
    }
  });

  // insert query
  const fields = selectedFields.map(f => "`" + f.field + "`").join(", ");
  const qsMarks = selectedFields.map(_ => "?").join(", ");
  const bindVars = selectedFields.map(f => "$" + f.field).join(", ");
  const bindTypes = "s".repeat(selectedFields.length);

  save += `\n  $stmt = $conn->prepare("INSERT INTO \`${tableName}\` (${fields}) VALUES (${qsMarks})");\n`;
  save += `  $stmt->bind_param("${bindTypes}", ${bindVars});\n`;
  save += `  if($stmt->execute()){\n`;
  save += `    header("Location: form_${tableName}.php?success=1");\n`;
  save += `    exit;\n`;
  save += `  }else{\n`;
  save += `    echo "Insert Failed: " . $stmt->error;\n`;
  save += `  }\n`;
  save += `  $stmt->close();\n`;
  save += `}\n?>\n`;

  document.getElementById("formCode").value = form;
  document.getElementById("saveCode").value = save;
}

// show/hide select options input
function initSelectToggles(){
  qsa(".inputType").forEach(sel => {
    const field = sel.dataset.field;
    const box = qs(`.selectBox[data-field="${field}"]`);
    const refresh = () => {
      if(sel.value === "select") box.classList.remove("hidden");
      else box.classList.add("hidden");
    };
    sel.addEventListener("change", refresh);
    refresh();
  });
}
initSelectToggles();

// html escape
function escapeHtml(str){
  return String(str)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}
</script>

</body>
</html>
<?php $conn->close(); ?>
