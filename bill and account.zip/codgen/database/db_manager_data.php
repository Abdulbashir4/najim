<?php
require_once __DIR__ . '/../../server_connection.php';

function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function cleanName($v){ return preg_replace('/[^a-zA-Z0-9_]/', '', (string)$v); }

$table = cleanName($_GET['table'] ?? '');
if(!$table){
  die("No table selected. Go back and select a table.");
}

$msg = "";
$err = "";

// ---------- Detect Primary Key ----------
$pk = null;
$pkRes = $conn->query("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
if($pkRes && $pkRes->num_rows > 0){
  $pkRow = $pkRes->fetch_assoc();
  $pk = $pkRow['Column_name'] ?? null;
}

// ---------- Get Columns ----------
$columns = [];
$colRes = $conn->query("SHOW COLUMNS FROM `$table`");
if($colRes){
  while($c = $colRes->fetch_assoc()){
    $columns[] = $c; // Field, Type, Null, Key, Default, Extra
  }
} else {
  die("Invalid table.");
}

// helper columns list
$fieldNames = array_map(fn($c) => $c['Field'], $columns);

// ---------- Handle POST Actions ----------
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $action = $_POST['action'] ?? '';

  // DELETE ROW
  if($action === 'delete_row'){
    if(!$pk){
      $err = "❌ Cannot delete: Primary key not found for this table.";
    } else {
      $id = $_POST['pk_value'] ?? '';
      $stmt = $conn->prepare("DELETE FROM `$table` WHERE `$pk` = ? LIMIT 1");
      $stmt->bind_param("s", $id);
      if($stmt->execute()){
        $msg = "✅ Row deleted successfully.";
      } else {
        $err = "❌ Delete failed: " . $stmt->error;
      }
      $stmt->close();
    }
  }

  // INSERT ROW
  if($action === 'insert_row'){
    $fields = [];
    $placeholders = [];
    $values = [];

    foreach($columns as $c){
      $f = $c['Field'];

      // skip auto increment column
      if(stripos($c['Extra'], 'auto_increment') !== false) continue;

      $fields[] = "`$f`";
      $placeholders[] = "?";
      $values[] = $_POST["col_$f"] ?? null;
    }

    if(empty($fields)){
      $err = "❌ No insertable column found.";
    } else {
      $sql = "INSERT INTO `$table` (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";
      $stmt = $conn->prepare($sql);

      // dynamic types all string (safe & simple)
      $types = str_repeat("s", count($values));
      $stmt->bind_param($types, ...$values);

      if($stmt->execute()){
        $msg = "✅ Row inserted successfully.";
      } else {
        $err = "❌ Insert failed: " . $stmt->error;
      }
      $stmt->close();
    }
  }

  // UPDATE ROW
  if($action === 'update_row'){
    if(!$pk){
      $err = "❌ Cannot update: Primary key not found for this table.";
    } else {
      $pkValue = $_POST['pk_value'] ?? '';

      $sets = [];
      $values = [];

      foreach($columns as $c){
        $f = $c['Field'];

        // don't update PK if it is auto increment or primary
        if($f === $pk) continue;

        // skip auto increment too
        if(stripos($c['Extra'], 'auto_increment') !== false) continue;

        $sets[] = "`$f` = ?";
        $values[] = $_POST["col_$f"] ?? null;
      }

      $values[] = $pkValue;

      if(empty($sets)){
        $err = "❌ Nothing to update.";
      } else {
        $sql = "UPDATE `$table` SET " . implode(', ', $sets) . " WHERE `$pk` = ? LIMIT 1";
        $stmt = $conn->prepare($sql);

        $types = str_repeat("s", count($values));
        $stmt->bind_param($types, ...$values);

        if($stmt->execute()){
          $msg = "✅ Row updated successfully.";
        } else {
          $err = "❌ Update failed: " . $stmt->error;
        }
        $stmt->close();
      }
    }
  }
}

// ---------- Search & Pagination ----------
$search = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 15;
$offset = ($page - 1) * $limit;

// build search query
$whereSql = "";
$params = [];
$types = "";

if($search !== ""){
  $like = "%$search%";
  $likeClauses = [];
  foreach($fieldNames as $f){
    $likeClauses[] = "`$f` LIKE ?";
    $params[] = $like;
    $types .= "s";
  }
  $whereSql = " WHERE " . implode(" OR ", $likeClauses);
}

// count rows
$countSql = "SELECT COUNT(*) AS total FROM `$table`" . $whereSql;
$countStmt = $conn->prepare($countSql);
if($search !== ""){
  $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$countRes = $countStmt->get_result();
$totalRows = (int)($countRes->fetch_assoc()['total'] ?? 0);
$countStmt->close();

$totalPages = max(1, (int)ceil($totalRows / $limit));

// fetch rows
$dataSql = "SELECT * FROM `$table`" . $whereSql . " LIMIT $limit OFFSET $offset";
$dataStmt = $conn->prepare($dataSql);
if($search !== ""){
  $dataStmt->bind_param($types, ...$params);
}
$dataStmt->execute();
$dataRes = $dataStmt->get_result();

$rows = [];
while($r = $dataRes->fetch_assoc()){
  $rows[] = $r;
}
$dataStmt->close();

// ---------- If Edit ----------
$editPkValue = $_GET['edit'] ?? '';
$editRow = null;
if($editPkValue !== '' && $pk){
  $editStmt = $conn->prepare("SELECT * FROM `$table` WHERE `$pk` = ? LIMIT 1");
  $editStmt->bind_param("s", $editPkValue);
  $editStmt->execute();
  $editRes = $editStmt->get_result();
  $editRow = $editRes->fetch_assoc();
  $editStmt->close();
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <title>DB Data Manager</title>
</head>
<body class="bg-slate-50">

<div class="max-w-7xl mx-auto p-6">

  <!-- Header -->
  <div class="flex items-center justify-between mb-4">
    <div>
      <h1 class="text-2xl font-bold text-gray-800">📄 Data Manager</h1>
      <p class="text-sm text-gray-500">
        Table: <b><?= h($table) ?></b>
        <?php if($pk): ?> • Primary Key: <b><?= h($pk) ?></b><?php endif; ?>
      </p>
    </div>

    <div class="flex gap-2">
      <a href="db_manager.php?table=<?= urlencode($table) ?>"
         class="px-4 py-2 rounded-xl bg-white border hover:bg-slate-50 text-sm font-semibold">
        ← Back
      </a>
    </div>
  </div>

  <?php if($msg): ?>
    <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl text-green-700"><?= h($msg) ?></div>
  <?php endif; ?>
  <?php if($err): ?>
    <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700"><?= h($err) ?></div>
  <?php endif; ?>

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

    <!-- LEFT: Insert / Edit -->
    <div class="bg-white border rounded-2xl p-4">
      <h2 class="font-bold text-gray-800 mb-3">
        <?= $editRow ? "✏️ Edit Row" : "➕ Insert New Row" ?>
      </h2>

      <form method="POST" class="space-y-3">
        <?php if($editRow): ?>
          <input type="hidden" name="action" value="update_row">
          <input type="hidden" name="pk_value" value="<?= h($editPkValue) ?>">
        <?php else: ?>
          <input type="hidden" name="action" value="insert_row">
        <?php endif; ?>

        <?php foreach($columns as $c): 
          $f = $c['Field'];
          $type = strtolower($c['Type']);
          $isAuto = (stripos($c['Extra'], 'auto_increment') !== false);

          // hide auto increment in insert
          if(!$editRow && $isAuto) continue;

          $val = $editRow ? ($editRow[$f] ?? '') : '';
        ?>
          <div>
            <label class="text-xs font-semibold text-gray-600"><?= h($f) ?> <span class="text-gray-400">(<?= h($c['Type']) ?>)</span></label>

            <?php if(str_contains($type, 'text')): ?>
              <textarea name="col_<?= h($f) ?>" rows="3"
                class="mt-1 w-full border rounded-xl px-3 py-2 text-sm"><?= h($val) ?></textarea>
            <?php else: ?>
              <input
                name="col_<?= h($f) ?>"
                value="<?= h($val) ?>"
                class="mt-1 w-full border rounded-xl px-3 py-2 text-sm"
                <?= ($editRow && $pk && $f === $pk) ? "readonly" : "" ?>
              >
            <?php endif; ?>

            <?php if($editRow && $pk && $f === $pk): ?>
              <p class="text-[11px] text-gray-400 mt-1">Primary key locked</p>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>

        <button class="w-full px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold">
          <?= $editRow ? "Update" : "Insert" ?>
        </button>

        <?php if($editRow): ?>
          <a href="db_manager_data.php?table=<?= urlencode($table) ?>"
             class="block text-center w-full px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-gray-800 text-sm font-semibold">
            Cancel Edit
          </a>
        <?php endif; ?>
      </form>
    </div>

    <!-- RIGHT: Data Table -->
    <div class="lg:col-span-2 bg-white border rounded-2xl p-4 overflow-hidden">

      <!-- Search + Info -->
      <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
        <form class="flex gap-2 w-full md:w-auto" method="GET">
          <input type="hidden" name="table" value="<?= h($table) ?>">
          <input name="search" value="<?= h($search) ?>" placeholder="Search..."
                 class="w-full md:w-80 border rounded-xl px-3 py-2 text-sm">
          <button class="px-4 py-2 rounded-xl bg-gray-800 hover:bg-black text-white text-sm font-semibold">
            Search
          </button>
        </form>

        <div class="text-sm text-gray-500">
          Total Rows: <b class="text-gray-800"><?= $totalRows ?></b>
        </div>
      </div>

      <!-- Rows -->
      <div class="overflow-auto border rounded-2xl">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-100">
            <tr class="text-gray-700">
              <?php foreach($fieldNames as $f): ?>
                <th class="text-left px-4 py-3 whitespace-nowrap"><?= h($f) ?></th>
              <?php endforeach; ?>
              <th class="text-left px-4 py-3 w-40">Action</th>
            </tr>
          </thead>

          <tbody class="divide-y">
            <?php if(empty($rows)): ?>
              <tr>
                <td colspan="<?= count($fieldNames) + 1 ?>" class="px-4 py-8 text-center text-gray-500">
                  No data found.
                </td>
              </tr>
            <?php else: ?>
              <?php foreach($rows as $r): ?>
                <tr class="hover:bg-slate-50">
                  <?php foreach($fieldNames as $f): ?>
                    <td class="px-4 py-2 whitespace-nowrap">
                      <?php
                        $val = $r[$f] ?? '';
                        $txt = (string)$val;
                        if(strlen($txt) > 60) $txt = substr($txt, 0, 60) . "…";
                        echo h($txt);
                      ?>
                    </td>
                  <?php endforeach; ?>

                  <td class="px-4 py-2">
                    <div class="flex gap-2">
                      <?php if($pk): ?>
                        <a href="db_manager_data.php?table=<?= urlencode($table) ?>&page=<?= $page ?>&search=<?= urlencode($search) ?>&edit=<?= urlencode((string)($r[$pk] ?? '')) ?>"
                           class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold">
                          Edit
                        </a>

                        <form method="POST" onsubmit="return confirm('Delete this row?')">
                          <input type="hidden" name="action" value="delete_row">
                          <input type="hidden" name="pk_value" value="<?= h($r[$pk] ?? '') ?>">
                          <button class="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold">
                            Delete
                          </button>
                        </form>
                      <?php else: ?>
                        <span class="text-xs text-gray-400">No PK</span>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div class="mt-4 flex items-center justify-between text-sm">
        <div class="text-gray-500">
          Page <b class="text-gray-800"><?= $page ?></b> of <b class="text-gray-800"><?= $totalPages ?></b>
        </div>

        <div class="flex gap-2">
          <?php
            $base = "db_manager_data.php?table=" . urlencode($table) . "&search=" . urlencode($search);
          ?>
          <a class="px-3 py-1.5 rounded-lg border bg-white hover:bg-slate-50 <?= $page<=1?'pointer-events-none opacity-50':'' ?>"
             href="<?= $base ?>&page=<?= max(1,$page-1) ?>">
             ← Prev
          </a>

          <a class="px-3 py-1.5 rounded-lg border bg-white hover:bg-slate-50 <?= $page>=$totalPages?'pointer-events-none opacity-50':'' ?>"
             href="<?= $base ?>&page=<?= min($totalPages,$page+1) ?>">
             Next →
          </a>
        </div>
      </div>

    </div>

  </div>

</div>

</body>
</html>
<?php $conn->close(); ?>
