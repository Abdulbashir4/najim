<?php
require_once __DIR__ . '/../function/db_helper.php';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Data Table: orders</title>
</head>

<body class="bg-slate-100 min-h-screen">

  <header class="bg-white border-b">
    <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
      <div>
        <h1 class="text-xl font-bold text-gray-800">Data Table: orders</h1>
        <p class="text-sm text-gray-500">Auto generated from Codgen DB Viewer</p>
      </div>

      <div class="text-xs text-gray-500 text-right">
        Generated: <b>2026-01-13 19:36:08</b><br>
        Table: <b>orders</b>
      </div>
    </div>
  </header>

  <main class="max-w-7xl mx-auto px-4 py-6">
    <div class="bg-white border rounded-2xl shadow-sm p-4">
      <?php
      echo db_table(
        'orders',
        'order_status = \'Pending\'',
        [],
        '*',
        '1',
        50,
        ["title" => "Data Table: orders"]
      );
      ?>
    </div>
  </main>

</body>
</html>