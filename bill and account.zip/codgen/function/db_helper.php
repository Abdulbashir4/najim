<?php
/**
 * Codgen DB Helper Library
 * Use anywhere to fetch single values or render HTML tables easily.
 */

require_once __DIR__ . '/../../server_connection.php';

/** escape html */
function h($v){
  return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}

/** keep only safe table/column names */
function db_clean_name($v){
  return preg_replace('/[^a-zA-Z0-9_]/', '', (string)$v);
}

/**
 * ✅ Get Single Value
 * Example:
 *   echo db_value("orders", "total_amount", "order_id=5");
 */
function db_value($table, $column, $where = "1", $params = []){
  global $conn;

  $table  = db_clean_name($table);
  $column = db_clean_name($column);

  if(!$table || !$column) return null;

  $sql = "SELECT `$column` AS val FROM `$table` WHERE $where LIMIT 1";
  $stmt = $conn->prepare($sql);

  if(!$stmt) return null;

  if(!empty($params)){
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
  }

  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res ? $res->fetch_assoc() : null;
  $stmt->close();

  return $row['val'] ?? null;
}

/**
 * ✅ Get Row (Assoc Array)
 * Example:
 *   $row = db_row("orders","order_id=?", [5]);
 */
function db_row($table, $where = "1", $params = [], $columns="*"){
  global $conn;

  $table = db_clean_name($table);
  if(!$table) return null;

  $sql = "SELECT $columns FROM `$table` WHERE $where LIMIT 1";
  $stmt = $conn->prepare($sql);
  if(!$stmt) return null;

  if(!empty($params)){
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
  }

  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res ? $res->fetch_assoc() : null;
  $stmt->close();

  return $row;
}

/**
 * ✅ Get List of Rows
 * Example:
 *   $list = db_list("orders", "order_status=?", ["pending"], "*", "created_at DESC", 50);
 */
function db_list($table, $where="1", $params=[], $columns="*", $orderBy="", $limit=100){
  global $conn;

  $table = db_clean_name($table);
  if(!$table) return [];

  $orderSql = $orderBy ? " ORDER BY $orderBy" : "";
  $limit = (int)$limit;
  if($limit <= 0) $limit = 100;

  $sql = "SELECT $columns FROM `$table` WHERE $where $orderSql LIMIT $limit";
  $stmt = $conn->prepare($sql);
  if(!$stmt) return [];

  if(!empty($params)){
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
  }

  $stmt->execute();
  $res = $stmt->get_result();

  $rows = [];
  while($res && ($r = $res->fetch_assoc())){
    $rows[] = $r;
  }
  $stmt->close();

  return $rows;
}

/**
 * ✅ Render Any Table as HTML Table
 * Example:
 *   echo db_table("orders", "1", [], ["order_id","customer_name","total_amount"], "order_id DESC", 20);
 *
 * columns can be:
 * - "*" = all columns
 * - ["col1","col2"] selected columns
 */
function db_table($table, $where="1", $params=[], $columns="*", $orderBy="", $limit=50, $options=[]){
  global $conn;

  $table = db_clean_name($table);
  if(!$table) return "<div class='text-red-600'>Invalid table</div>";

  // columns handling
  $colSql = "*";
  $colArr = [];

  if(is_array($columns)){
    $safeCols = [];
    foreach($columns as $c){
      $c = db_clean_name($c);
      if($c) {
        $safeCols[] = "`$c`";
        $colArr[] = $c;
      }
    }
    if(!empty($safeCols)){
      $colSql = implode(", ", $safeCols);
    }
  } else {
    $colSql = ($columns === "*" ? "*" : $columns);
  }

  $orderSql = $orderBy ? " ORDER BY $orderBy" : "";
  $limit = (int)$limit;
  if($limit <= 0) $limit = 50;

  $sql = "SELECT $colSql FROM `$table` WHERE $where $orderSql LIMIT $limit";
  $stmt = $conn->prepare($sql);

  if(!$stmt){
    return "<div class='text-red-600'>Query prepare failed.</div>";
  }

  if(!empty($params)){
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
  }

  $stmt->execute();
  $res = $stmt->get_result();

  $rows = [];
  while($res && ($r = $res->fetch_assoc())){
    $rows[] = $r;
  }

  $stmt->close();

  if(empty($rows)){
    return "<div class='text-gray-500 text-sm'>No data found.</div>";
  }

  // auto header columns
  if($columns === "*" || !is_array($columns)){
    $colArr = array_keys($rows[0]);
  }

  $title = $options['title'] ?? "";
  $class = $options['class'] ?? "w-full text-sm";
  $maxLen = (int)($options['maxLen'] ?? 80);

  ob_start();
  ?>
  <div class="bg-white border rounded-2xl overflow-hidden">
    <?php if($title): ?>
      <div class="px-4 py-3 bg-slate-50 font-bold text-gray-800 border-b"><?= h($title) ?></div>
    <?php endif; ?>

    <div class="overflow-auto">
      <table class="<?= h($class) ?>">
        <thead class="bg-slate-100">
          <tr>
            <?php foreach($colArr as $c): ?>
              <th class="text-left px-4 py-3 whitespace-nowrap font-bold text-gray-700"><?= h($c) ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody class="divide-y">
          <?php foreach($rows as $r): ?>
            <tr class="hover:bg-slate-50">
              <?php foreach($colArr as $c): 
                $v = $r[$c] ?? '';
                $txt = (string)$v;
                if(mb_strlen($txt) > $maxLen) $txt = mb_substr($txt,0,$maxLen) . "…";
              ?>
                <td class="px-4 py-2 whitespace-nowrap text-gray-700"><?= h($txt) ?></td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php
  return ob_get_clean();
}

/**
 * ✅ Quick Print (Echo)
 * Example:
 *   db_print("orders","1",[],["order_id","total_amount"],"order_id DESC",20);
 */
function db_print($table, $where="1", $params=[], $columns="*", $orderBy="", $limit=50, $options=[]){
  echo db_table($table, $where, $params, $columns, $orderBy, $limit, $options);
}
