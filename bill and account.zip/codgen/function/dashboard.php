<?php require_once __DIR__ . '/../config.php'; ?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Codgen Dashboard</title>
</head>

<body class="bg-slate-100 overflow-hidden">

  <!-- ======= HEADER (FIXED) ======= -->
  <header class="fixed top-0 left-0 right-0 z-50 bg-white border-b h-16">
    <div class="h-full px-4 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold">
          C
        </div>
        <div>
          <h1 class="text-lg font-bold text-gray-800 leading-tight">Codgen Admin</h1>
          <p class="text-xs text-gray-500 -mt-1">Professional Dashboard Panel</p>
        </div>
      </div>

      <div class="flex items-center gap-3">
        <button class="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">
          🔔 Notifications
        </button>
        <div class="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-lg">
          <div class="w-8 h-8 rounded-full bg-gray-300"></div>
          <div class="text-sm">
            <div class="font-semibold text-gray-700">Admin</div>
            <div class="text-xs text-gray-500">Super User</div>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- ======= SIDEBAR (FIXED) ======= -->
  <aside class="fixed top-16 left-0 bottom-0 w-72 bg-white border-r p-4 hidden md:block overflow-y-auto">
    <div class="mb-4">
      <h2 class="text-sm font-bold text-gray-700 uppercase tracking-wider">Navigation</h2>
    </div>

    <nav class="space-y-2">

      <button onclick="loadPage(BASE + '/database/db_manager.php')" class="navBtn border border-1 border-gray-400  py-1 rounded hover:bg-blue-200 w-40">🗃️ DB Manager</button>

<button onclick="loadPage(BASE + '/database/form_generator.php')" class="navBtn border border-1 border-gray-400  py-1 rounded hover:bg-blue-200 w-40">🧩 Form Generator</button>
<button onclick="loadPage(BASE + '/function/db_viewer.php')" class="navBtn border border-1 border-gray-400  py-1 rounded hover:bg-blue-200 w-40">
  <span class="text-lg">👁️</span> Table Genarator
</button>

      <button
        onclick="loadPage('pages/settings.php', 'Settings', 'System configuration & preferences')"
        class="navBtn w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-blue-50 text-gray-700 font-semibold transition">
        <span class="text-lg">⚙️</span> Settings
      </button>

    </nav>

    <div class="mt-6 p-4 rounded-xl bg-slate-50 border">
      <p class="text-sm text-gray-600 font-semibold">Tips</p>
      <p class="text-xs text-gray-500 mt-1">
        Sidebar fixed থাকবে। শুধু content area scroll হবে।
      </p>
    </div>
  </aside>

  <!-- ======= CONTENT AREA (SCROLLABLE) ======= -->
  <main class="pt-16 md:ml-72 h-screen overflow-y-auto">
    <div>

      <!-- iframe wrapper -->
      <div class="bg-white shadow-sm overflow-hidden">
        <iframe
          id="mainFrame"
          src="../database/db_manager.php"
          class="w-full h-[100vh] bg-white"
          frameborder="0"
        ></iframe>
      </div>

    </div>
  </main>

  <script>
  const BASE = "<?= CODGEN_BASE ?>";  // /tarek/codgen or /basir/codgen ...

  let currentUrl = BASE + "/database/db_manager.php";

  function loadPage(url){
    currentUrl = url;
    document.getElementById("mainFrame").src = url;

    document.querySelectorAll(".navBtn").forEach(btn => {
      btn.classList.remove("bg-blue-600", "text-white");
      btn.classList.add("text-gray-700");
    });

    event.target.closest("button").classList.add("bg-blue-600", "text-white");
    event.target.closest("button").classList.remove("text-gray-700");
  }

  function reloadFrame(){
    document.getElementById("mainFrame").src = currentUrl;
  }

  function openFrameNewTab(){
    window.open(currentUrl, "_blank");
  }
</script>


</body>
</html>
