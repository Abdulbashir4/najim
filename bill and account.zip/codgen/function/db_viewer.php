<?php
// db_viewer.php (FINAL WORKING VERSION)
require_once __DIR__ . '/../function/db_helper.php'; // db_helper.php includes server_connection.php

function cleanName($v){ return preg_replace('/[^a-zA-Z0-9_]/', '', (string)$v); }
function cleanFileName($v){
  $v = strtolower(trim((string)$v));
  $v = preg_replace('/[^a-z0-9_\-]/', '_', $v);
  $v = preg_replace('/_+/', '_', $v);
  $v = trim($v, '_');
  if($v === '') $v = 'page_' . date('Ymd_His');
  return $v;
}

/**
 * Basic (strict) ORDER BY sanitizer:
 * Allows: `col`, `col DESC`, `col ASC`
 * Blocks: `;`, `--`, complex injections.
 */
function cleanOrderBy($order, $allowedCols = []){
  $order = trim((string)$order);
  if($order === '') return '';

  // remove extra spaces
  $order = preg_replace('/\s+/', ' ', $order);

  // allow multiple order by separated by comma (optional)
  $parts = array_map('trim', explode(',', $order));
  $safeParts = [];

  foreach($parts as $p){
    if($p === '') continue;

    // pattern: col [ASC|DESC]
    if(!preg_match('/^([a-zA-Z0-9_]+)(\s+(ASC|DESC))?$/i', $p, $m)){
      continue;
    }

    $col = $m[1];
    $dir = strtoupper($m[3] ?? '');

    // if allowedCols given, must exist
    if(!empty($allowedCols) && !in_array($col, $allowedCols)){
      continue;
    }

    $safeParts[] = $dir ? "$col $dir" : $col;
  }

  return implode(', ', $safeParts);
}

// -------------------- Tables --------------------
$tables = [];
$res = $conn->query("SHOW TABLES");
if($res){
  while($r = $res->fetch_array()){
    $tables[] = $r[0];
  }
}

// -------------------- GET selections --------------------
$table = cleanName($_GET['table'] ?? '');
$where = trim($_GET['where'] ?? '1');
$order = trim($_GET['order'] ?? '');
$limit = (int)($_GET['limit'] ?? 20);
if($limit <= 0) $limit = 20;

$selectedCols = $_GET['cols'] ?? [];
if(!is_array($selectedCols)) $selectedCols = [];
$selectedCols = array_values(array_filter(array_map('cleanName', $selectedCols)));

$filename = cleanFileName($_GET['filename'] ?? '');

// columns list for selected table
$cols = [];
if($table){
  $cRes = $conn->query("SHOW COLUMNS FROM `$table`");
  if($cRes){
    while($c = $cRes->fetch_assoc()){
      $cols[] = $c['Field'];
    }
  }
}

// ✅ ORDER BY sanitize using cols list
$order = cleanOrderBy($order, $cols);

// -------------------- AJAX: DISTINCT VALUES (MUST BE BEFORE HTML) --------------------
if(($_GET['ajax'] ?? '') === 'distinct_values'){
  header('Content-Type: application/json; charset=utf-8');

  $t = cleanName($_GET['table'] ?? '');
  $col = cleanName($_GET['col'] ?? '');
  $q = trim($_GET['q'] ?? '');
  $max = (int)($_GET['max'] ?? 50);
  if($max <= 0) $max = 50;
  if($max > 200) $max = 200;

  if(!$t || !$col){
    echo json_encode(["ok"=>false, "items"=>[], "error"=>"Invalid table/column"]);
    exit;
  }

  // verify column exists in that table
  $exists = false;
  $cRes = $conn->query("SHOW COLUMNS FROM `$t`");
  if($cRes){
    while($c = $cRes->fetch_assoc()){
      if($c['Field'] === $col){ $exists = true; break; }
    }
  }
  if(!$exists){
    echo json_encode(["ok"=>false, "items"=>[], "error"=>"Column not found"]);
    exit;
  }

  // build query
  $whereLike = "";
  if($q !== ""){
    $qEsc = $conn->real_escape_string($q);
    $whereLike = "WHERE `$col` LIKE '%{$qEsc}%'";
  }

  $sql = "SELECT DISTINCT `$col` AS v
          FROM `$t`
          $whereLike
          ORDER BY v
          LIMIT $max";

  $items = [];
  $r = $conn->query($sql);
  if($r){
    while($row = $r->fetch_assoc()){
      $items[] = $row['v'];
    }
  }

  echo json_encode(["ok"=>true, "items"=>$items, "error"=>""]);
  exit;
}

// -------------------- Columns param for db_table() --------------------
$colsParam = "*";
$colsCode = "'*'"; // default string '*'

if(!empty($selectedCols)){
  $colsParam = $selectedCols;
  $colsCode = "[" . implode(", ", array_map(function($c){ return "'".$c."'"; }, $selectedCols)) . "]";
}

// ✅ used for heredoc (NO EXPRESSION INSIDE HEREDOC)
$pageTitle = $table ? "Data Table: $table" : "Data Table";
$now = date("Y-m-d H:i:s");
$whereCode = $where ? var_export($where, true) : "'1'";
$orderCode = $order ? var_export($order, true) : "''";

// -------------------- Generated FULL Page Code --------------------
$generatedCode = <<<PHP
<?php
require_once __DIR__ . '/../function/db_helper.php';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <title>{$pageTitle}</title>
</head>

<body class="bg-slate-100 min-h-screen">

  <header class="bg-white border-b">
    <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
      <div>
        <h1 class="text-xl font-bold text-gray-800">{$pageTitle}</h1>
        <p class="text-sm text-gray-500">Auto generated from Codgen DB Viewer</p>
      </div>

      <div class="text-xs text-gray-500 text-right">
        Generated: <b>{$now}</b><br>
        Table: <b>{$table}</b>
      </div>
    </div>
  </header>

  <main class="max-w-7xl mx-auto px-4 py-6">
    <div class="bg-white border rounded-2xl shadow-sm p-4">
      <?php
      echo db_table(
        '{$table}',
        {$whereCode},
        [],
        {$colsCode},
        {$orderCode},
        {$limit},
        ["title" => "{$pageTitle}"]
      );
      ?>
    </div>
  </main>

</body>
</html>
PHP;

// -------------------- SAVE FEATURE --------------------
$msg = "";
$err = "";
$savedUrl = "";

if($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_page'){

  $postTable = cleanName($_POST['table'] ?? '');
  if(!$postTable){
    $err = "❌ Please select a table first!";
  } else {

    $postWhere = trim($_POST['where'] ?? '1');
    $postOrderRaw = trim($_POST['order'] ?? '');

    // build cols list for sanitizing ORDER in saved page too
    $postColsList = [];
    $cRes2 = $conn->query("SHOW COLUMNS FROM `$postTable`");
    if($cRes2){
      while($c = $cRes2->fetch_assoc()){
        $postColsList[] = $c['Field'];
      }
    }
    $postOrder = cleanOrderBy($postOrderRaw, $postColsList);

    $postLimit = (int)($_POST['limit'] ?? 20);
    if($postLimit <= 0) $postLimit = 20;

    $postCols = $_POST['cols'] ?? [];
    if(!is_array($postCols)) $postCols = [];
    $postCols = array_values(array_filter(array_map('cleanName', $postCols)));

    $postFilename = cleanFileName($_POST['filename'] ?? '');
    if($postFilename === '') $postFilename = cleanFileName($postTable . "_" . date('Ymd_His'));

    // build colsCode
    $postColsCode = "'*'";
    if(!empty($postCols)){
      $postColsCode = "[" . implode(", ", array_map(function($c){ return "'".$c."'"; }, $postCols)) . "]";
    }

    $saveTitle = "Data Table: " . $postTable;
    $saveNow = date("Y-m-d H:i:s");
    $postWhereCode = $postWhere ? var_export($postWhere, true) : "'1'";
    $postOrderCode = $postOrder ? var_export($postOrder, true) : "''";

    $saveCode = <<<PHP
<?php
require_once __DIR__ . '/../function/db_helper.php';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <title>{$saveTitle}</title>
</head>

<body class="bg-slate-100 min-h-screen">

  <header class="bg-white border-b">
    <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
      <div>
        <h1 class="text-xl font-bold text-gray-800">{$saveTitle}</h1>
        <p class="text-sm text-gray-500">Auto generated from Codgen DB Viewer</p>
      </div>

      <div class="text-xs text-gray-500 text-right">
        Generated: <b>{$saveNow}</b><br>
        Table: <b>{$postTable}</b>
      </div>
    </div>
  </header>

  <main class="max-w-7xl mx-auto px-4 py-6">
    <div class="bg-white border rounded-2xl shadow-sm p-4">
      <?php
      echo db_table(
        '{$postTable}',
        {$postWhereCode},
        [],
        {$postColsCode},
        {$postOrderCode},
        {$postLimit},
        ["title" => "{$saveTitle}"]
      );
      ?>
    </div>
  </main>

</body>
</html>
PHP;

    // save directory: /codgen/generated_pages
    $saveDir = realpath(__DIR__ . '/..') . '/generated_pages';
    if(!is_dir($saveDir)){
      mkdir($saveDir, 0777, true);
    }

    $filePath = $saveDir . '/' . $postFilename . '.php';

    // avoid overwrite
    if(file_exists($filePath)){
      $filePath = $saveDir . '/' . $postFilename . '_' . date('His') . '.php';
    }

    $ok = file_put_contents($filePath, $saveCode);

    if($ok === false){
      $err = "❌ Failed to save file. Permission issue? Check generated_pages write permission.";
    } else {
      // build url
      $script = $_SERVER['SCRIPT_NAME'];
      $pos = strpos($script, '/codgen/');
      $base = $pos !== false ? substr($script, 0, $pos) . '/codgen' : rtrim(dirname(dirname($script)), '/');

      $savedUrl = $base . '/generated_pages/' . basename($filePath);
      $msg = "✅ Page saved successfully: " . basename($filePath);
    }
  }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <title>DB Viewer + Generator</title>
</head>
<body class="bg-slate-50">

<div class="max-w-7xl mx-auto p-6">

  <div class="flex items-center justify-between mb-4">
    <div>
      <h1 class="text-2xl font-bold text-gray-800">🧠 DB Viewer + Page Generator</h1>
      <p class="text-sm text-gray-500">Select → Preview → Generate Code → Save as New Page</p>
    </div>
  </div>

  <?php if($msg): ?>
    <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl text-green-700">
      <?= h($msg) ?>
      <?php if($savedUrl): ?>
        <div class="mt-2">
          <a href="<?= h($savedUrl) ?>" target="_blank"
             class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold">
            ↗ Open Saved Page
          </a>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if($err): ?>
    <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700">
      <?= h($err) ?>
    </div>
  <?php endif; ?>

  <!-- GET FORM -->
  <form method="GET" class="bg-white border rounded-2xl p-4 mb-4">
    <div class="grid grid-cols-1 md:grid-cols-5 gap-3">

      <div class="md:col-span-2">
        <label class="text-xs font-bold text-gray-600">Table</label>
        <select name="table" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm" onchange="this.form.submit()">
          <option value="">-- Select Table --</option>
          <?php foreach($tables as $t): ?>
            <option value="<?= h($t) ?>" <?= $table===$t?'selected':'' ?>><?= h($t) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div>
        <label class="text-xs font-bold text-gray-600">Limit</label>
        <input type="number" name="limit" value="<?= h($limit) ?>" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm">
      </div>

      <!-- ✅ ORDER BY SELECT SYSTEM -->
      <div class="md:col-span-2">
        <label class="text-xs font-bold text-gray-600">ORDER BY</label>

        <div class="mt-1 grid grid-cols-1 md:grid-cols-3 gap-2">
          <select id="orderCol" class="w-full border rounded-xl px-3 py-2 text-sm">
            <option value="">-- Column --</option>
            <?php foreach($cols as $c): ?>
              <option value="<?= h($c) ?>"><?= h($c) ?></option>
            <?php endforeach; ?>
          </select>

          <select id="orderDir" class="w-full border rounded-xl px-3 py-2 text-sm">
            <option value="ASC">ASC</option>
            <option value="DESC">DESC</option>
          </select>

          <button type="button" onclick="applyOrderBy()"
                  class="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-xs font-bold">
            ✅ Apply
          </button>
        </div>

        <input name="order" value="<?= h($order) ?>" placeholder="Example: id DESC"
               class="mt-2 w-full border rounded-xl px-3 py-2 text-sm">
        <p class="text-[11px] text-gray-500 mt-1">
          আপনি dropdown দিয়ে select করতে পারবেন, অথবা manual লিখতে পারবেন।
        </p>
      </div>

      <div class="md:col-span-5">
        <label class="text-xs font-bold text-gray-600">WHERE (SQL condition)</label>
        <input name="where" value="<?= h($where) ?>" placeholder="Example: status='pending'"
               class="mt-1 w-full border rounded-xl px-3 py-2 text-sm">
      </div>

      <!-- ✅ Advanced Conditions Builder -->
      <div class="md:col-span-5">
        <div class="flex items-center justify-between">
          <label class="text-xs font-bold text-gray-600">⚡ Advanced Conditions Builder</label>

          <button type="button" onclick="addConditionRow()"
            class="text-xs font-bold px-3 py-1 rounded-lg bg-slate-200 hover:bg-slate-300">
            ➕ Add Condition
          </button>
        </div>

        <div id="conditionsWrap"
          class="mt-2 border rounded-2xl p-3 bg-slate-50 space-y-2">

          <div class="condRow flex flex-col md:flex-row gap-2 items-start md:items-center">

            <select class="colSel w-full md:w-1/4 border rounded-xl px-3 py-2 text-sm"
                    onchange="onColumnChange(this)">
              <option value="">-- Column --</option>
              <?php foreach($cols as $c): ?>
                <option value="<?= h($c) ?>"><?= h($c) ?></option>
              <?php endforeach; ?>
            </select>

            <select class="opSel w-full md:w-1/6 border rounded-xl px-3 py-2 text-sm">
              <option value="=">=</option>
              <option value="!=">!=</option>
              <option value=">">&gt;</option>
              <option value=">=">&gt;=</option>
              <option value="<">&lt;</option>
              <option value="<=">&lt;=</option>
              <option value="LIKE">LIKE</option>
              <option value="IN">IN</option>
            </select>

            <div class="w-full md:w-2/5 space-y-1">
              <input class="valInp w-full border rounded-xl px-3 py-2 text-sm"
                     placeholder="Value e.g. 2 / done / %text%">

              <div class="flex gap-2">
                <select class="valPick w-full border rounded-xl px-3 py-2 text-sm bg-white"
                        onchange="applyPickedValue(this)">
                  <option value="">-- Pick value --</option>
                </select>

                <button type="button" onclick="loadDistinctValues(this)"
                        class="loadPickBtn px-3 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-xs font-bold">
                  ↻ Load
                </button>
              </div>

              <input class="valSearch w-full border rounded-xl px-3 py-2 text-xs"
                     placeholder="Search value (optional) যেমন: do / 2 / rah...">
            </div>

            <select class="joinSel w-full md:w-1/6 border rounded-xl px-3 py-2 text-sm">
              <option value="AND">AND</option>
              <option value="OR">OR</option>
            </select>

            <button type="button" onclick="removeCondRow(this)"
              class="px-3 py-2 rounded-xl bg-red-100 hover:bg-red-200 text-red-700 text-sm font-bold">
              ✖
            </button>

          </div>

        </div>

        <div class="mt-2 flex gap-2">
          <button type="button" onclick="buildWhereFromConditions()"
            class="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm">
            🧩 Build WHERE
          </button>

          <button type="button" onclick="clearConditions()"
            class="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-gray-800 font-bold text-sm">
            🧹 Clear
          </button>
        </div>

        <p class="text-[11px] text-gray-500 mt-2">
          ✅ Example: user_id = 2 AND sale_status = done
        </p>
      </div>

      <div class="md:col-span-5">
        <label class="text-xs font-bold text-gray-600">Columns (optional)</label>
        <div class="mt-2 grid grid-cols-2 md:grid-cols-4 gap-2 max-h-40 overflow-auto border rounded-2xl p-3 bg-slate-50">
          <?php if(!$table): ?>
            <div class="text-sm text-gray-500">👆 আগে table select করুন</div>
          <?php else: ?>
            <?php foreach($cols as $c): ?>
              <label class="flex items-center gap-2 text-sm">
                <input type="checkbox" name="cols[]" value="<?= h($c) ?>" <?= in_array($c, $selectedCols) ? 'checked' : '' ?>>
                <span><?= h($c) ?></span>
              </label>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <div class="md:col-span-5 flex gap-2">
        <button class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm">
          🔎 Preview + Generate Code
        </button>

        <button type="button" onclick="copyCode()"
                class="px-5 py-2 rounded-xl bg-gray-800 hover:bg-black text-white font-bold text-sm">
          📋 Copy Code
        </button>
      </div>

    </div>
  </form>

  <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

    <!-- Preview -->
    <div class="bg-white border rounded-2xl p-4 overflow-hidden">
      <h2 class="font-bold text-gray-800 mb-3">✅ Preview Output</h2>

      <?php if(!$table): ?>
        <div class="text-gray-500 text-sm">👆 table select করে Preview করুন।</div>
      <?php else: ?>
        <?= db_table($table, $where ?: "1", [], $colsParam, $order, $limit, ["title" => "Preview: $table (LIMIT $limit)"]); ?>
      <?php endif; ?>
    </div>

    <!-- Generated Code + Save -->
    <div class="bg-white border rounded-2xl p-4">
      <div class="flex items-center justify-between mb-2">
        <h2 class="font-bold text-gray-800">🧾 Generated Full Page Code</h2>
        <span class="text-xs text-gray-500">HTML + Tailwind</span>
      </div>

      <textarea id="codeBox" class="w-full h-[45vh] border rounded-2xl p-3 font-mono text-xs"><?= h($generatedCode) ?></textarea>

      <div class="mt-4 border-t pt-4">
        <h3 class="font-bold text-gray-800 mb-2">💾 Generate & Save Page</h3>

        <form method="POST" class="flex flex-col md:flex-row gap-2 items-start md:items-end">
          <input type="hidden" name="action" value="save_page">

          <input type="hidden" name="table" value="<?= h($table) ?>">
          <input type="hidden" name="where" value="<?= h($where) ?>">
          <input type="hidden" name="order" value="<?= h($order) ?>">
          <input type="hidden" name="limit" value="<?= h($limit) ?>">

          <?php foreach($selectedCols as $c): ?>
            <input type="hidden" name="cols[]" value="<?= h($c) ?>">
          <?php endforeach; ?>

          <div class="flex-1 w-full">
            <label class="text-xs font-bold text-gray-600">File Name</label>
            <input name="filename" value="<?= h($filename ?: ($table ? $table."_table" : "")) ?>"
                   placeholder="example: orders_pending"
                   class="mt-1 w-full border rounded-xl px-3 py-2 text-sm">
            <p class="text-[11px] text-gray-400 mt-1">
              Save location: <b>/codgen/generated_pages/</b>
            </p>
          </div>

          <button class="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm w-full md:w-auto">
            ✅ Generate & Save Page
          </button>
        </form>

      </div>

    </div>

  </div>

</div>

<script>
function copyCode(){
  const ta = document.getElementById('codeBox');
  ta.select();
  document.execCommand('copy');
  alert("✅ Code copied!");
}

// ✅ ORDER BY apply
function applyOrderBy(){
  const col = document.getElementById('orderCol')?.value || '';
  const dir = document.getElementById('orderDir')?.value || 'ASC';
  const orderInput = document.querySelector('input[name="order"]');

  if(!orderInput) return;

  if(!col){
    alert("⚠️ ORDER BY column select করুন");
    return;
  }

  orderInput.value = `${col} ${dir}`;
  alert("✅ ORDER BY applied!");
}

// ---- Advanced WHERE Builder ----
function addConditionRow(){
  const wrap = document.getElementById('conditionsWrap');
  const first = wrap.querySelector('.condRow');
  const clone = first.cloneNode(true);

  clone.querySelector('.colSel').value = '';
  clone.querySelector('.opSel').value = '=';
  clone.querySelector('.valInp').value = '';
  clone.querySelector('.joinSel').value = 'AND';

  if(clone.querySelector('.valPick')){
    clone.querySelector('.valPick').innerHTML = `<option value="">-- Pick value --</option>`;
  }
  if(clone.querySelector('.valSearch')){
    clone.querySelector('.valSearch').value = '';
  }

  wrap.appendChild(clone);
}

function removeCondRow(btn){
  const wrap = document.getElementById('conditionsWrap');
  const rows = wrap.querySelectorAll('.condRow');
  if(rows.length <= 1){
    alert("⚠️ Minimum 1 condition row required.");
    return;
  }
  btn.closest('.condRow').remove();
}

function escapeSQLValue(v){
  v = String(v);
  if(/^-?\d+(\.\d+)?$/.test(v)) return v;
  v = v.replace(/'/g, "\\'");
  return "'" + v + "'";
}

function buildWhereFromConditions(){
  const wrap = document.getElementById('conditionsWrap');
  const rows = wrap.querySelectorAll('.condRow');
  let parts = [];

  rows.forEach((r) => {
    const col = r.querySelector('.colSel').value.trim();
    const op  = r.querySelector('.opSel').value.trim();
    const val = r.querySelector('.valInp').value.trim();
    const join = r.querySelector('.joinSel').value.trim();

    if(!col || !op || val === '') return;

    let expr = '';
    if(op === 'LIKE'){
      expr = `${col} LIKE ${escapeSQLValue(val)}`;
    } else if(op === 'IN'){
      const items = val.split(',').map(x => x.trim()).filter(Boolean).map(escapeSQLValue);
      if(items.length > 0){
        expr = `${col} IN (${items.join(', ')})`;
      }
    } else {
      expr = `${col} ${op} ${escapeSQLValue(val)}`;
    }

    if(expr){
      if(parts.length > 0) parts.push(join);
      parts.push(expr);
    }
  });

  const whereInput = document.querySelector('input[name="where"]');
  whereInput.value = parts.length ? parts.join(' ') : '1';
  alert("✅ WHERE generated!");
}

function clearConditions(){
  const wrap = document.getElementById('conditionsWrap');
  const first = wrap.querySelector('.condRow');
  wrap.innerHTML = '';
  wrap.appendChild(first);

  first.querySelector('.colSel').value = '';
  first.querySelector('.opSel').value = '=';
  first.querySelector('.valInp').value = '';
  first.querySelector('.joinSel').value = 'AND';

  if(first.querySelector('.valPick')){
    first.querySelector('.valPick').innerHTML = `<option value="">-- Pick value --</option>`;
  }
  if(first.querySelector('.valSearch')){
    first.querySelector('.valSearch').value = '';
  }

  document.querySelector('input[name="where"]').value = '1';
}

// ---- VALUE PICKER FEATURES ----
function getSelectedTable(){
  const tableSel = document.querySelector('select[name="table"]');
  return tableSel ? tableSel.value : '';
}

function applyPickedValue(sel){
  const row = sel.closest('.condRow');
  const inp = row.querySelector('.valInp');
  if(inp) inp.value = sel.value;
}

function onColumnChange(sel){
  const row = sel.closest('.condRow');

  const pick = row.querySelector('.valPick');
  if(pick) pick.innerHTML = `<option value="">-- Pick value --</option>`;

  const btn = row.querySelector('.loadPickBtn');
  if(btn) loadDistinctValues(btn);
}

async function loadDistinctValues(btn){
  const row = btn.closest('.condRow');
  const table = getSelectedTable();
  const col = row.querySelector('.colSel').value;
  const pick = row.querySelector('.valPick');
  const search = row.querySelector('.valSearch')?.value?.trim() || "";

  if(!table){
    alert("⚠️ আগে Table select করুন");
    return;
  }
  if(!col){
    alert("⚠️ আগে Column select করুন");
    return;
  }

  pick.innerHTML = `<option value="">Loading...</option>`;

  try{
    const url = `?ajax=distinct_values&table=${encodeURIComponent(table)}&col=${encodeURIComponent(col)}&q=${encodeURIComponent(search)}&max=80`;
    const res = await fetch(url);
    const data = await res.json();

    if(!data.ok){
      pick.innerHTML = `<option value="">-- Pick value --</option>`;
      alert("❌ Failed: " + (data.error || "Unknown"));
      return;
    }

    let html = `<option value="">-- Pick value -- (${data.items.length})</option>`;
    data.items.forEach(v=>{
      const txt = (v === null || v === undefined || v === '') ? '(empty)' : String(v);
      html += `<option value="${txt.replace(/"/g,'&quot;')}">${txt}</option>`;
    });

    pick.innerHTML = html;

  }catch(e){
    pick.innerHTML = `<option value="">-- Pick value --</option>`;
    alert("❌ Network error");
  }
}
</script>

</body>
</html>
