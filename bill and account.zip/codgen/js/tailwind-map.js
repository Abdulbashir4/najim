const TAILWIND_MAP = {
  padding: {
    '4px': 'p-1',
    '8px': 'p-2',
    '16px': 'p-4',
    '24px': 'p-6',
    '32px': 'p-8'
  },
  margin: {
    '4px': 'm-1',
    '8px': 'm-2',
    '16px': 'm-4',
    '24px': 'm-6'
  },
  display: {
    'block': 'block',
    'flex': 'flex',
    'grid': 'grid'
  },
  textAlign: {
    'left': 'text-left',
    'center': 'text-center',
    'right': 'text-right'
  }
};
