/* =================================================
   GLOBAL STATE
================================================= */

let isDraggingBlock = false;
let selectedBlock = null;
let previewMode = 'desktop';

/* =================================================
   DOM READY
================================================= */

document.addEventListener('DOMContentLoaded', () => {

    loadPanel('panels/blocks.html', 'blockPanel', bindBlockEvents);
    loadPanel('panels/styles.html', 'stylePanel');

    document.getElementById('tabBlock').onclick = showBlockTab;
    document.getElementById('tabStyle').onclick = showStyleTab;

    document.getElementById('btnMobile').onclick  = () => setPreviewMode('mobile');
    document.getElementById('btnDesktop').onclick = () => setPreviewMode('desktop');
    document.getElementById('btnCode').onclick    = exportPureHTML;

    const canvas = document.getElementById('canvas');
    canvas.addEventListener('click', onCanvasClick);

    enableDropTarget(canvas);
});

/* =================================================
   PANEL LOADER
================================================= */

function loadPanel(url, targetId, callback) {
    fetch(url)
        .then(res => res.text())
        .then(html => {
            document.getElementById(targetId).innerHTML = html;
            if (callback) callback();
        });
}

/* =================================================
   TAB HANDLING
================================================= */

function showBlockTab() {
    document.getElementById('blockPanel').classList.remove('hidden');
    document.getElementById('stylePanel').classList.add('hidden');
}

function showStyleTab() {
    document.getElementById('stylePanel').classList.remove('hidden');
    document.getElementById('blockPanel').classList.add('hidden');
}

/* =================================================
   BLOCK PANEL
================================================= */

function bindBlockEvents() {
    document.querySelectorAll('.block-item').forEach(block => {

        block.setAttribute('draggable', 'true');

        block.addEventListener('dragstart', e => {
            isDraggingBlock = true;
            e.dataTransfer.setData('text/plain', block.dataset.block);
        });

        block.addEventListener('dragend', () => {
            setTimeout(() => {
                isDraggingBlock = false;
            }, 100);
        });

        block.addEventListener('click', e => {
            if (isDraggingBlock) {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            addBlockToCanvas(block.dataset.block);
        });
    });
}

/* =================================================
   BLOCK FACTORY
================================================= */

function addBlockToCanvas(type) {
    const canvas = document.getElementById('canvas');
    const el = createBlock(type);
    if (!el) return;

    const target = getInsertTarget(type) || canvas;
    target.appendChild(el);
}

/* =================================================
   CREATE BLOCK
================================================= */

function createBlock(type) {
    let el;

    switch (type) {

        case 'section':
            el = document.createElement('section');
            el.className = 'block-wrapper border border-dashed p-6 space-y-4 bg-gray-50 relative';
            el.dataset.canvasBlock = 'section';
            el.dataset.isContainer = "true";

            el.innerHTML = `<div class="text-xs text-gray-400">Section</div>`;
            enableDropTarget(el);
            addRemoveButton(el);
            break;

        case 'inner-section':
            el = document.createElement('div');
            el.className = 'block-wrapper flex gap-4 border border-dashed p-4 bg-white';
            el.dataset.canvasBlock = 'inner-section';
            el.dataset.isContainer = "true";

            el.append(createColumn(), createColumn());
            enableDropTarget(el);
            addRemoveButton(el);
            break;

        case 'column':
            el = createColumn();
            break;

        case 'text':
            el = document.createElement('p');
            el.textContent = 'Edit text';
            el.contentEditable = true;
            el.className = 'block-wrapper';
            el.dataset.canvasBlock = 'text';
            addRemoveButton(el);
            break;

        case 'heading':
            el = document.createElement('h2');
            el.textContent = 'Heading';
            el.contentEditable = true;
            el.className = 'block-wrapper text-2xl font-bold';
            el.dataset.canvasBlock = 'heading';
            addRemoveButton(el);
            break;

        case 'button':
            el = document.createElement('button');
            el.textContent = 'Click Me';
            el.className = 'block-wrapper bg-blue-600 text-white px-4 py-2 rounded';
            el.dataset.canvasBlock = 'button';
            addRemoveButton(el);
            break;

        case 'image':
            el = createImageBlock();
            addRemoveButton(el);
            break;

        default:
            el = document.createElement('div');
            el.textContent = type;
            el.className = 'block-wrapper';
            el.dataset.canvasBlock = type;
            addRemoveButton(el);
    }

    return el;
}

/* =================================================
   COLUMN
================================================= */

function createColumn() {
    const col = document.createElement('div');
    col.className = 'block-wrapper border border-dashed p-2 min-h-[40px]';
    col.dataset.canvasBlock = 'column';
    col.dataset.isContainer = "true";

    col.style.flex = '0 0 50%';
    col.style.maxWidth = '50%';

    enableDropTarget(col);
    addRemoveButton(col);
    return col;
}

/* =================================================
   INSERT TARGET LOGIC
================================================= */

function getInsertTarget(type) {
    if (!selectedBlock) return null;

    if (isContentBlock(type)) {
        return selectedBlock.closest('[data-canvas-block="column"]');
    }

    if (isContainerBlock(type)) {
        return selectedBlock.dataset.isContainer
            ? selectedBlock
            : selectedBlock.closest('[data-is-container="true"]');
    }

    return null;
}

function isContentBlock(type) {
    return ['text','heading','image','button'].includes(type);
}

function isContainerBlock(type) {
    return ['section','inner-section','column'].includes(type);
}

/* =================================================
   IMAGE BLOCK
================================================= */

function createImageBlock() {
    const wrap = document.createElement('div');
    wrap.className = 'block-wrapper border border-dashed p-4 text-center';
    wrap.dataset.canvasBlock = 'image';

    const img = document.createElement('img');
    img.className = 'max-w-full mx-auto hidden';

    const input = document.createElement('input');
    input.type = 'file';
    input.className = 'hidden';

    const btn = document.createElement('button');
    btn.textContent = 'Upload Image';
    btn.onclick = () => input.click();

    input.onchange = e => {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onload = () => {
            img.src = reader.result;
            img.classList.remove('hidden');
            btn.remove();
        };
        reader.readAsDataURL(file);
    };

    wrap.append(btn, input, img);
    return wrap;
}

/* =================================================
   CANVAS SELECT
================================================= */

function onCanvasClick(e) {
    if (isDraggingBlock) return;
    if (previewMode !== 'desktop') return;

    const block = e.target.closest('[data-canvas-block]');
    if (!block) return;

    document.querySelectorAll('.selected-block')
        .forEach(b => b.classList.remove('selected-block'));

    selectedBlock = block;
    block.classList.add('selected-block');

    window.onBlockSelect?.(block);
}

/* =================================================
   PREVIEW MODE
================================================= */

function setPreviewMode(mode) {
    previewMode = mode;
    const canvas = document.getElementById('canvas');
    const sidebar = document.querySelector('aside');

    if (mode === 'mobile') {
        sidebar.classList.add('hidden');
        canvas.style.width = '375px';
    } else {
        sidebar.classList.remove('hidden');
        canvas.style.width = '100%';
    }
}

/* =================================================
   EXPORT
================================================= */

function exportPureHTML() {
    const clone = document.getElementById('canvas').cloneNode(true);
    clone.querySelectorAll('[contenteditable]').forEach(e => e.removeAttribute('contenteditable'));
    clone.querySelectorAll('.selected-block').forEach(e => e.classList.remove('selected-block'));
    clone.querySelectorAll('.remove-btn').forEach(e => e.remove());

    openCodeModal(clone.innerHTML);
}

/* =================================================
   MODAL
================================================= */

function openCodeModal(code) {
    document.getElementById('codeModal').classList.remove('hidden');
    document.getElementById('codeOutput').value = code;
}

function closeCodeModal() {
    document.getElementById('codeModal').classList.add('hidden');
}

/* =================================================
   DRAG & DROP TARGET
================================================= */

function enableDropTarget(el) {
    el.addEventListener('dragover', e => {
        e.preventDefault();
        el.classList.add('drop-hover');
    });

    el.addEventListener('dragleave', () => {
        el.classList.remove('drop-hover');
    });

    el.addEventListener('drop', e => {
        e.preventDefault();
        e.stopPropagation();

        el.classList.remove('drop-hover');

        const type = e.dataTransfer.getData('text/plain');
        if (!type) return;

        isDraggingBlock = true;
        selectedBlock = el;
        addBlockToCanvas(type);

        setTimeout(() => {
            isDraggingBlock = false;
        }, 0);
    });
}

/* =================================================
   REMOVE BUTTON
================================================= */

function addRemoveButton(el) {
    const btn = document.createElement('div');
    btn.className = 'remove-btn';
    btn.textContent = '✕';

    btn.onclick = e => {
        e.stopPropagation();
        el.remove();
    };

    el.appendChild(btn);
}


function addResizeHandles(el) {
    el.style.position = el.style.position || 'relative';

    const right = document.createElement('div');
    right.className = 'resize-handle resize-e';

    const bottom = document.createElement('div');
    bottom.className = 'resize-handle resize-s';

    const corner = document.createElement('div');
    corner.className = 'resize-handle resize-se';

    el.append(right, bottom, corner);

    initResize(el, right, 'e');
    initResize(el, bottom, 's');
    initResize(el, corner, 'se');
}
function initResize(el, handle, direction) {

    let startX, startY, startW, startH;

    handle.addEventListener('mousedown', e => {
        e.stopPropagation();
        e.preventDefault();

        startX = e.clientX;
        startY = e.clientY;

        startW = el.offsetWidth;
        startH = el.offsetHeight;

        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });

    function onMove(e) {
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        if (direction.includes('e')) {
            el.style.width = Math.max(20, startW + dx) + 'px';
        }

        if (direction.includes('s')) {
            el.style.height = Math.max(20, startH + dy) + 'px';
        }
    }

    function onUp() {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
    }
}
