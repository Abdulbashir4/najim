/* =================================================
   INTERACTIONS STATE
================================================= */

let isDraggingBlock = false;

/* =================================================
   BLOCK PANEL DRAG
================================================= */

function bindBlockEvents() {
    document.querySelectorAll('.block-item').forEach(block => {

        block.draggable = true;

        block.addEventListener('dragstart', e => {
            isDraggingBlock = true;
            e.dataTransfer.setData('text/plain', block.dataset.block);
        });

        block.addEventListener('dragend', () => {
            setTimeout(() => isDraggingBlock = false, 100);
        });

        block.addEventListener('click', e => {
            if (isDraggingBlock) return;
            addBlockToCanvas(block.dataset.block);
        });
    });
}

/* =================================================
   INIT BLOCK INTERACTIONS
================================================= */

function initBlockInteractions(el) {
    enableDropTarget(el);
    addRemoveButton(el);
    addResizeHandles(el);
}

/* =================================================
   DRAG & DROP TARGET
================================================= */

function enableDropTarget(el) {
    el.addEventListener('dragover', e => {
        e.preventDefault();
        el.classList.add('drop-hover');
    });

    el.addEventListener('dragleave', () => {
        el.classList.remove('drop-hover');
    });

    el.addEventListener('drop', e => {
        e.preventDefault();
        e.stopPropagation();

        const type = e.dataTransfer.getData('text/plain');
        if (!type) return;

        isDraggingBlock = true;
        selectedBlock = el;
        addBlockToCanvas(type);

        setTimeout(() => isDraggingBlock = false, 0);
    });
}

/* =================================================
   REMOVE BUTTON
================================================= */

function addRemoveButton(el) {
    const btn = document.createElement('div');
    btn.className = 'remove-btn';
    btn.textContent = '✕';

    btn.onclick = e => {
        e.stopPropagation();
        el.remove();
    };

    el.appendChild(btn);
}

/* =================================================
   RESIZE HANDLES
================================================= */

function addResizeHandles(el) {
    el.style.position ||= 'relative';

    ['t','r','b','l','tl','tr','bl','br'].forEach(dir => {
        const h = document.createElement('div');
        h.className = `resize-handle resize-${dir}`;
        el.appendChild(h);
        initResize(el, h, dir);
    });
}

/* =================================================
   RESIZE ENGINE (FIXED)
================================================= */

function initResize(el, handle, dir) {

    let sx, sy, sw, sh, sl, st, isAbsolute;

    handle.addEventListener('mousedown', e => {
        e.preventDefault();
        e.stopPropagation();

        const rect = el.getBoundingClientRect();

        sx = e.clientX;
        sy = e.clientY;
        sw = rect.width;
        sh = rect.height;
        sl = el.offsetLeft;
        st = el.offsetTop;

        // 🔥 only non-flex blocks can move
        isAbsolute = !['column','inner-section'].includes(el.dataset.canvasBlock);

        if (isAbsolute) {
            el.style.position = 'absolute';
            el.style.left = sl + 'px';
            el.style.top  = st + 'px';
        }

        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });

    function onMove(e) {
        const dx = e.clientX - sx;
        const dy = e.clientY - sy;

        /* -------- WIDTH -------- */
        if (dir.includes('r')) resizeWidth(sw + dx);
        if (dir.includes('l') && isAbsolute) {
            resizeWidth(sw - dx);
            el.style.left = sl + dx + 'px';
        }

        /* -------- HEIGHT -------- */
        if (dir.includes('b')) resizeHeight(sh + dy);
        if (dir.includes('t') && isAbsolute) {
            resizeHeight(sh - dy);
            el.style.top = st + dy + 'px';
        }
    }

    function resizeWidth(w) {
        w = Math.max(20, w);

        if (el.dataset.canvasBlock === 'column') {
            const pw = el.parentElement.offsetWidth;
            const pct = (w / pw) * 100;
            el.style.flex = `0 0 ${pct}%`;
            el.style.maxWidth = `${pct}%`;
        } else {
            el.style.width = w + 'px';
        }
    }

    function resizeHeight(h) {
        el.style.height = Math.max(20, h) + 'px';
    }

    function onUp() {
        document.body.style.userSelect = '';
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
    }
}
