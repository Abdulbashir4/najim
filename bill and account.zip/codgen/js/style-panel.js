/* =================================================
   STYLE PANEL ENGINE
================================================= */

document.addEventListener('DOMContentLoaded', () => {

    const widthRange = document.getElementById('columnWidthRange');
    const widthValue = document.getElementById('columnWidthValue');

    window.onBlockSelect = function (block) {
        const type = block.dataset.canvasBlock;

        // hide all
        document.querySelectorAll('.style-group')
            .forEach(g => g.classList.add('hidden'));

        // show relevant
        const groups = STYLE_GROUP_MAP[type] || [];
        groups.forEach(group => {
            const el = document.querySelector(`[data-style-group="${group}"]`);
            if (el) el.classList.remove('hidden');
        });

        populateAllDropdowns(block);

        // column width
        if (type === 'column' && widthRange) {
            const basis = block.style.flexBasis || '50%';
            const val = parseInt(basis);

            widthRange.value = val;
            widthValue.textContent = val;

            widthRange.oninput = () => {
                const w = widthRange.value;
                widthValue.textContent = w;
                block.style.flex = `0 0 ${w}%`;
                block.style.maxWidth = `${w}%`;
            };
        }
    };
});

/* =================================================
   DROPDOWNS
================================================= */

function populateAllDropdowns(block) {
    document.querySelectorAll('[data-tw-group]').forEach(select => {
        const group = select.dataset.twGroup;
        const options = TW_SCHEMA[group];
        if (!options) return;

        select.innerHTML = '<option value="">Default</option>';

        options.forEach(cls => {
            const opt = document.createElement('option');
            opt.value = cls;
            opt.textContent = cls;
            select.appendChild(opt);
        });

        select.onchange = () => {
            applyTailwindClass(block, group, select.value);
        };
    });
}

function applyTailwindClass(el, group, value) {
    if (!value) return;
    const allowed = TW_SCHEMA[group];
    el.classList.remove(...allowed);
    el.classList.add(value);
}
