/* =================================================
   GLOBAL STATE
================================================= */

let selectedBlock = null;
let previewMode = 'desktop';

/* =================================================
   DOM READY
================================================= */

document.addEventListener('DOMContentLoaded', () => {

    loadPanel('panels/blocks.html', 'blockPanel', bindBlockEvents);
    loadPanel('panels/styles.html', 'stylePanel');

    document.getElementById('tabBlock').onclick = showBlockTab;
    document.getElementById('tabStyle').onclick = showStyleTab;

    document.getElementById('btnMobile').onclick  = () => setPreviewMode('mobile');
    document.getElementById('btnDesktop').onclick = () => setPreviewMode('desktop');
    document.getElementById('btnCode').onclick    = exportPureHTML;

    document.getElementById('canvas')
        .addEventListener('click', onCanvasClick);
});

/* =================================================
   PANEL LOADER
================================================= */

function loadPanel(url, targetId, callback) {
    fetch(url)
        .then(res => res.text())
        .then(html => {
            document.getElementById(targetId).innerHTML = html;
            callback?.();
        });
}

/* =================================================
   TABS
================================================= */

function showBlockTab() {
    document.getElementById('blockPanel').classList.remove('hidden');
    document.getElementById('stylePanel').classList.add('hidden');
}

function showStyleTab() {
    document.getElementById('stylePanel').classList.remove('hidden');
    document.getElementById('blockPanel').classList.add('hidden');
}

/* =================================================
   BLOCK FACTORY
================================================= */

function addBlockToCanvas(type) {
    const canvas = document.getElementById('canvas');
    const el = createBlock(type);
    if (!el) return;

    const target = getInsertTarget(type) || canvas;
    target.appendChild(el);
}

function createBlock(type) {
    let el;

    switch (type) {

        case 'section':
            el = document.createElement('section');
            el.className = 'block-wrapper border border-dashed p-6 space-y-4 bg-gray-50 relative';
            el.dataset.canvasBlock = 'section';
            el.dataset.isContainer = "true";
            el.innerHTML = `<div class="text-xs text-gray-400">Section</div>`;
            break;

        case 'inner-section':
            el = document.createElement('div');
            el.className = 'block-wrapper flex gap-4 border border-dashed p-4 bg-white';
            el.dataset.canvasBlock = 'inner-section';
            el.dataset.isContainer = "true";
            el.append(createColumn(), createColumn());
            break;

        case 'column':
            el = createColumn();
            break;

        case 'text':
            el = document.createElement('p');
            el.textContent = 'Edit text';
            el.contentEditable = true;
            el.className = 'block-wrapper';
            el.dataset.canvasBlock = 'text';
            break;

        case 'heading':
            el = document.createElement('h2');
            el.textContent = 'Heading';
            el.contentEditable = true;
            el.className = 'block-wrapper text-2xl font-bold';
            el.dataset.canvasBlock = 'heading';
            break;

        case 'button':
            el = document.createElement('button');
            el.textContent = 'Click Me';
            el.className = 'block-wrapper bg-blue-600 text-white px-4 py-2 rounded';
            el.dataset.canvasBlock = 'button';
            break;

        case 'image':
            el = createImageBlock();
            break;
    }

    if (el) {
        initBlockInteractions(el); // 🔥 hook
    }

    return el;
}

function createColumn() {
    const col = document.createElement('div');
    col.className = 'block-wrapper border border-dashed p-2 min-h-[40px]';
    col.dataset.canvasBlock = 'column';
    col.dataset.isContainer = "true";

    col.style.flex = '0 0 50%';
    col.style.maxWidth = '50%';

    initBlockInteractions(col); // 🔥 hook
    return col;
}

/* =================================================
   INSERT TARGET LOGIC
================================================= */

function getInsertTarget(type) {
    if (!selectedBlock) return null;

    if (['text','heading','image','button'].includes(type)) {
        return selectedBlock.closest('[data-canvas-block="column"]');
    }

    if (['section','inner-section','column'].includes(type)) {
        return selectedBlock.dataset.isContainer
            ? selectedBlock
            : selectedBlock.closest('[data-is-container="true"]');
    }

    return null;
}

/* =================================================
   IMAGE BLOCK
================================================= */

function createImageBlock() {
    const wrap = document.createElement('div');
    wrap.className = 'block-wrapper border border-dashed p-4 text-center';
    wrap.dataset.canvasBlock = 'image';

    const img = document.createElement('img');
    img.className = 'max-w-full mx-auto hidden';

    const input = document.createElement('input');
    input.type = 'file';
    input.className = 'hidden';

    const btn = document.createElement('button');
    btn.textContent = 'Upload Image';
    btn.onclick = () => input.click();

    input.onchange = e => {
        const reader = new FileReader();
        reader.onload = () => {
            img.src = reader.result;
            img.classList.remove('hidden');
            btn.remove();
        };
        reader.readAsDataURL(e.target.files[0]);
    };

    wrap.append(btn, input, img);
    return wrap;
}

/* =================================================
   CANVAS SELECT
================================================= */

function onCanvasClick(e) {
    const block = e.target.closest('[data-canvas-block]');
    if (!block) return;

    document.querySelectorAll('.selected-block')
        .forEach(b => b.classList.remove('selected-block'));

    selectedBlock = block;
    block.classList.add('selected-block');

    window.onBlockSelect?.(block);
}

/* =================================================
   PREVIEW + EXPORT
================================================= */

function setPreviewMode(mode) {
    previewMode = mode;
    const canvas = document.getElementById('canvas');
    const sidebar = document.querySelector('aside');

    sidebar.classList.toggle('hidden', mode === 'mobile');
    canvas.style.width = mode === 'mobile' ? '375px' : '100%';
}

function exportPureHTML() {
    const clone = document.getElementById('canvas').cloneNode(true);
    clone.querySelectorAll('[contenteditable], .remove-btn, .resize-handle')
         .forEach(e => e.remove());

    openCodeModal(clone.innerHTML);
}
