const TW_SCHEMA = {
    display: ['block', 'inline-block', 'flex', 'grid', 'hidden'],
    position: ['static', 'relative', 'absolute', 'fixed'],
    padding: ['p-0','p-2','p-4','p-6','p-8'],
    margin: ['m-0','m-2','m-4','m-6','m-8'],
    fontSize: ['text-sm','text-base','text-lg','text-xl','text-2xl'],
    fontWeight: ['font-normal','font-medium','font-bold'],
    textAlign: ['text-left','text-center','text-right'],
    color: ['text-black','text-gray-600','text-blue-600','text-red-500'],
    bgColor: ['bg-white','bg-gray-100','bg-blue-500','bg-red-500'],
    rounded: ['rounded-none','rounded','rounded-lg','rounded-full'],
    objectFit: ['object-cover','object-contain'],
    flex: [
        'flex-row','flex-col',
        'justify-start','justify-center','justify-between',
        'items-start','items-center','items-end',
        'gap-2','gap-4','gap-6'
    ]
};

const STYLE_GROUP_MAP = {
    section: ['layout','spacing','background'],
    'inner-section': ['layout','flex','spacing','background'],
    column: ['layout','flex','spacing','background','column-width'],
    text: ['typography','spacing'],
    heading: ['typography','spacing'],
    button: ['typography','spacing','background'],
    image: ['image','spacing'],
    navbar: ['layout','flex','spacing','background']
};
