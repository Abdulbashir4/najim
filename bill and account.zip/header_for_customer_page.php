<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="cus_header">
        <button class="cus_header_btn" onclick="window.location.href='admin.php'">Home</button>
        <button class="cus_header_btn" onclick="history.back()">Previus</button>
        <button class="cus_header_btn" onclick="printDiv('printArea')">🖨️ Print</button>

    </div>
</body>
</html>